Ext.define("Ext.locale.pt_BR.Component", {
    override: "Ext.Component"
});
