Ext.define("Ext.locale.pt_BR.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: 'Carregando...'
    }
});
