Ext.define('Ext.locale.pt_BR.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'Sem dados para exibir'
    }
});
