Ext.define('Ext.locale.pt_BR.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Carregando...'
    }
});
