Ext.define("Ext.locale.pt_BR.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: ""
    }
});
