Ext.define('Ext.locale.pt_BR.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Carregar mais...',
        noMoreRecordsText: 'Não há mais registros'
    }
});
