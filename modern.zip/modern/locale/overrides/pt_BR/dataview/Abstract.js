Ext.define('Ext.locale.pt_BR.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Carregando...'
    }
});
