Ext.define('Ext.locale.pt_BR.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "Recolher painel",
        expandToolText: "Expandir painel"
    }
});
