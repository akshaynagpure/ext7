Ext.define('Ext.locale.pt_BR.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: 'Não é um bloco CIDR válido'
    }
});
