Ext.define('Ext.locale.pt_BR.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'É um valor que foi excluído'
    }
});
