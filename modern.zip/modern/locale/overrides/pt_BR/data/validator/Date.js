Ext.define('Ext.locale.pt_BR.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "Não é uma data válida"
    }
});
