Ext.define('Ext.locale.pt_BR.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Não é uma URL válida'
    }
});
