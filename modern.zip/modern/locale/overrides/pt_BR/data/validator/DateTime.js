Ext.define('Ext.locale.pt_BR.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Não é uma data e hora válida'
    }
});
