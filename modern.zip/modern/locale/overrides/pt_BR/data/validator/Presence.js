Ext.define('Ext.locale.pt_BR.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: 'Este campo é necessário'
    }
});
