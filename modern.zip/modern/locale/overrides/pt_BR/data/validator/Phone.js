Ext.define('Ext.locale.pt_BR.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Não é um telefone válido'
    }
});
