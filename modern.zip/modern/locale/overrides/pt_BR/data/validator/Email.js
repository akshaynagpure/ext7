Ext.define('Ext.locale.pt_BR.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Não é um e-mail válido'
    }
});
