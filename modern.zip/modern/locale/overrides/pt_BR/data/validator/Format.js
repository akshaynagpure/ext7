Ext.define('Ext.locale.pt_BR.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'Está no formato incorreto'
    }
});
