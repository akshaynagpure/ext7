Ext.define('Ext.locale.pt_BR.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Não está na lista de valores válidos'
    }
});
