Ext.define('Ext.locale.pt_BR.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: 'Não é um bloco CIDR válido'
    }
});
