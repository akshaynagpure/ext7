Ext.define('Ext.locale.pt_BR.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Não é uma hora válida'
    }
});
