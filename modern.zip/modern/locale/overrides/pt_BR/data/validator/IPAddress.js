Ext.define('Ext.locale.pt_BR.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Não é um endereço IP válido'
    }
});
