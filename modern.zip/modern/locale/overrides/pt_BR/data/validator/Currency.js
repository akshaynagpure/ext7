Ext.define('Ext.locale.pt_BR.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Não é um valor monetário válido'
    }

});
