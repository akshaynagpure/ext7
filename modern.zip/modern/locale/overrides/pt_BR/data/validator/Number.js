Ext.define('Ext.locale.pt_BR.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Não é um número válido'
    }
});
