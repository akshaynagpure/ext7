Ext.define('Ext.locale.pt_BR.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'Concluído',
        monthText: 'Mês',
        dayText: 'Dia',
        yearText: 'Ano'
    }
});
