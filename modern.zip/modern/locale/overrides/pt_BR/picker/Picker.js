Ext.define('Ext.locale.pt_BR.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'Concluído',
        cancelButton: 'Cancelar'
    }
});
