Ext.define("Ext.locale.pt_BR.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "Mostrar em grupos"
    }
});
