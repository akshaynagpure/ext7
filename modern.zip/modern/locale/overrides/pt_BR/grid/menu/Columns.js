Ext.define("Ext.locale.pt_BR.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "Colunas"
    }
});
