Ext.define("Ext.locale.pt_BR.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "Ordenar crescente"
    }
});
