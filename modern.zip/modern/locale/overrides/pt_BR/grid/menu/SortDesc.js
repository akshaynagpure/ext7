Ext.define("Ext.locale.pt_BR.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "Ordenar decrescente"
    }
});
