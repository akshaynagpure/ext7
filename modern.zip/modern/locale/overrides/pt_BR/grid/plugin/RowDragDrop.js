Ext.define("Ext.locale.pt_BR.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} linha(s) selecionada(s)"
});
