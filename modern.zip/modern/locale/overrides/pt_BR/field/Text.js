Ext.define('Ext.locale.pt_BR.field.Text', {
    override: 'Ext.field.Text',

    badFormatMessage: 'Valor não está no formato desejado',
    config: {
        requiredMessage: 'Este campo é necessário',
        validationMessage: 'Está no formato incorreto'
    }
});
