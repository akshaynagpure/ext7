Ext.define('Ext.locale.pt_BR.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Este campo é necessário',
        validationMessage: 'Está no formato incorreto'
    }
});
