Ext.define('Ext.locale.pt_BR.field.Number', {
    override: 'Ext.field.Number',

    decimalsText: 'O valor máximo de decimais é {0}',
    minValueText: 'O valor mínimo para este campo é {0}',
    maxValueText: 'O valor máximo para este campo é {0}',
    badFormatMessage: 'Valor não é um número válido'
});
