Ext.define("Ext.locale.pt_BR.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: 'Arquivo...'
    }
});
