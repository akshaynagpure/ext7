Ext.define('Ext.locale.pt_BR.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'A data deste campo deve ser igual ou posterior à {0}',
    maxDateMessage: 'A data deste campo deve ser igual ou anterior à {0}'
});
