Ext.define('Ext.locale.pt_BR.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "Maximizar para tela cheia"
        },
        restoreTool: {
            tooltip: "Restaurar para o tamanho original"
        }
    }
});
