Ext.define('Ext.locale.ko.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "전체 화면으로 최대화"
        },
        restoreTool: {
            tooltip: "원래 크기로 복원 "
        }
    }
});
