Ext.define('Ext.locale.ko.ux.colorpick.Selector', {
    override: 'Ext.ux.colorpick.Selector',

    okButtonText: '확인',
    cancelButtonText: '취소'
});
