Ext.define('Ext.locale.ko.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: '반드시 존재해야합니다'
    }
});
