Ext.define('Ext.locale.ko.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: '유효한 날짜 및 시간이 아닙니다.'
    }
});
