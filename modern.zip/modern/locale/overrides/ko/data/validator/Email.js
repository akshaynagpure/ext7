Ext.define('Ext.locale.ko.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: '유효한 이메일 주소가 아닙니다.'
    }
});
