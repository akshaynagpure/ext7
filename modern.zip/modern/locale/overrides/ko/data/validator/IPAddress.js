Ext.define('Ext.locale.ko.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: '유효한 IP 주소가 아닙니다.'
    }
});
