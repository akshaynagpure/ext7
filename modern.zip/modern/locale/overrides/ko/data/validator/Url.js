Ext.define('Ext.locale.ko.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: '유효한 URL이 아닙니다.'
    }
});
