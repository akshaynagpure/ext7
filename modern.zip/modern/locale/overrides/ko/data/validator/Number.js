Ext.define('Ext.locale.ko.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: '숫자가 아닙니다'
    }
});
