Ext.define('Ext.locale.ko.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "유효한 날짜가 아닙니다."
    }
});
