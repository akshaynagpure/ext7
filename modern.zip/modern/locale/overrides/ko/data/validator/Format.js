Ext.define('Ext.locale.ko.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: '형식이 다릅니다'
    }
});
