Ext.define('Ext.locale.ko.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: '허용 되는 값 목록에 포함 되어 있지 않습니다. '
    }
});
