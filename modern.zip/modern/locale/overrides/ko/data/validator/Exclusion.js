Ext.define('Ext.locale.ko.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: '제외 된 가치인가요?'
    }
});
