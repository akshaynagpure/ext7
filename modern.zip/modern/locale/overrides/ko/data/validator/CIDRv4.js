Ext.define('Ext.locale.ko.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: '유효한 CIDR 블록이 아닙니다.'
    }
});
