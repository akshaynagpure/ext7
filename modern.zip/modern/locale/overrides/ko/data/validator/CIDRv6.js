Ext.define('Ext.locale.ko.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: '유효한 CIDR 블록이 아닙니다.'
    }
});
