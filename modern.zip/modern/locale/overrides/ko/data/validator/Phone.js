Ext.define('Ext.locale.ko.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: '올바른 전화 번호가 아닙니다.'
    }
});
