Ext.define('Ext.locale.ko.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: '유효한 통화 금액이 아닙니다.'
    }
});
