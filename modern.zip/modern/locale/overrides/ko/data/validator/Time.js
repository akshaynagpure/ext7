Ext.define('Ext.locale.ko.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: '유효한 시간이 아닙니다'
    }
});
