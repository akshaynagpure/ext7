Ext.define('Ext.locale.ko.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'done',
        cancelButton: '취소'
    }
});
