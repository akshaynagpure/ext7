Ext.define('Ext.locale.ko.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'done',
        monthText: '월',
        dayText: '일',
        yearText: '년'
    }
});
