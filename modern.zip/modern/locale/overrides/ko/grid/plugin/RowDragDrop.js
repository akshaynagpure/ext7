Ext.define("Ext.locale.ko.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} 개가 선택되었습니다."
});
