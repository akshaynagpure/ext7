Ext.define("Ext.locale.ko.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "이 항목별로 그룹화"
    }
});
