Ext.define("Ext.locale.ko.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "오름차순 정렬"
    }
});
