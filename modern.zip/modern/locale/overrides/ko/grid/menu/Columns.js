Ext.define("Ext.locale.ko.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "칼럼 목록"
    }
});
