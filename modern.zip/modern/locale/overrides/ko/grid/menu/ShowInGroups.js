Ext.define("Ext.locale.ko.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "그룹으로 표시"
    }
});
