Ext.define("Ext.locale.ko.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "내림차순 정렬"
    }
});
