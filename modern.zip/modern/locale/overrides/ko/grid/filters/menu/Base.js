Ext.define("Ext.locale.ko.grid.filters.menu.Base", {
    override: "Ext.grid.filters.menu.Base",

    config: {
        text: "필터"
    }
});
