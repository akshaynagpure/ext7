Ext.define('Ext.locale.ko.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: '이 필드의 날짜는 {0} 이후 날짜로 설정하십시오.',
    maxDateMessage: '이 필드의 날짜는 {0} 이전 날짜로 설정하십시오.'
});
