Ext.define('Ext.locale.ko.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: '이 필드는 필수입니다',
        validationMessage: '형식이 잘못되었습니다'
    }
});
