Ext.define('Ext.locale.ko.field.FileButton', {
    override: 'Ext.field.FileButton',

    config: {
        text: '리뷰 ...'
    }
});
