Ext.define('Ext.locale.ko.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "패널 닫기",
        expandToolText: "패널 열기"
    }
});
