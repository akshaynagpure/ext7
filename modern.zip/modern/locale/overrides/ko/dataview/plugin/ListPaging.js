Ext.define('Ext.locale.ko.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: '추가로드 ...',
        noMoreRecordsText: '더 이상 레코드 없음'
    }
});
