Ext.define('Ext.locale.ko.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: '로딩중...'
    }
});
