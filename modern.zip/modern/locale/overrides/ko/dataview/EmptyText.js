Ext.define('Ext.locale.ko.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: '표시 할 내용이 없습니다'
    }
});
