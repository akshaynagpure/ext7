Ext.define("Ext.locale.ko.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "표시 할 데이터가 없습니다"
    }
});
