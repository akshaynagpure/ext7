Ext.define('Ext.locale.ko.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: '로딩중...'
    }
});
