Ext.define("Ext.locale.ko.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: '로딩중...'
    }
});
