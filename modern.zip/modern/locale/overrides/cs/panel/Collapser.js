Ext.define('Ext.locale.cs.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "Zavřete okno",
        expandToolText: "rozbalte panel"
    }
});
