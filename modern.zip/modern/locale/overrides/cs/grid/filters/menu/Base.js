Ext.define("Ext.locale.cs.grid.filters.menu.Base", {
    override: "Ext.grid.filters.menu.Base",

    config: {
        text: "Filtr"
    }
});
