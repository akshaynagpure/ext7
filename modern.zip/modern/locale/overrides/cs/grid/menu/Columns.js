Ext.define("Ext.locale.cs.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "Sloupce"
    }
});
