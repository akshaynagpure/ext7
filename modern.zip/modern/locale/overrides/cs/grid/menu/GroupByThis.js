Ext.define("Ext.locale.cs.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "Seskupit podle toho"
    }
});
