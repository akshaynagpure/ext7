Ext.define("Ext.locale.cs.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "Zobrazit ve skupinách"
    }
});
