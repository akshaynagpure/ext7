Ext.define("Ext.locale.cs.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "Řadit sestupně"
    }
});
