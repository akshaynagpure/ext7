Ext.define("Ext.locale.cs.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "Řadit vzestupně"
    }
});
