Ext.define("Ext.locale.cs.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} vybraných řádků"
});
