Ext.define('Ext.locale.cs.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Není platné datum a čas'
    }
});
