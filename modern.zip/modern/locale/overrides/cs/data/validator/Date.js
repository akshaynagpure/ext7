Ext.define('Ext.locale.cs.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: 'Není platné datumčas'
    }
});
