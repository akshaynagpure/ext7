Ext.define('Ext.locale.cs.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'Má nesprávný formát'
    }
});
