Ext.define('Ext.locale.cs.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'Je hodnota, která byla vyloučena'
    }
});
