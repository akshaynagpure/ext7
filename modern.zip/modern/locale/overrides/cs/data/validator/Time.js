Ext.define('Ext.locale.cs.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Není platný čas'
    }
});
