Ext.define('Ext.locale.cs.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Není platná adresa URL'
    }
});
