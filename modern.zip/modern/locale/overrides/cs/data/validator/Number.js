Ext.define('Ext.locale.cs.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Není platné číslo'
    }
});
