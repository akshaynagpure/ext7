Ext.define('Ext.locale.cs.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Není platné telefonní číslo'
    }
});
