Ext.define('Ext.locale.cs.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Není platná částka měny'
    }
});
