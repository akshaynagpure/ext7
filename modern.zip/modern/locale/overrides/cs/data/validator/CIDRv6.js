Ext.define('Ext.locale.cs.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: 'Není platný blok CIDR'
    }
});
