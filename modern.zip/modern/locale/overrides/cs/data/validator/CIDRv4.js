Ext.define('Ext.locale.cs.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: 'Není platný blok CIDR'
    }
});
