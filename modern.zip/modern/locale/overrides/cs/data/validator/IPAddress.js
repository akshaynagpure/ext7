Ext.define('Ext.locale.cs.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Není platná adresa IP'
    }
});
