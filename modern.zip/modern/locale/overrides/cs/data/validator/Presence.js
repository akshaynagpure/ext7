Ext.define('Ext.locale.cs.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: 'Musí být přítomen'
    }
});
