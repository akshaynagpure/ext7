Ext.define('Ext.locale.cs.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Není platná e-mailová adresa'
    }
});
