Ext.define('Ext.locale.cs.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Het staat niet in de lijst se setkal s aanvaardbare waarden'
    }
});
