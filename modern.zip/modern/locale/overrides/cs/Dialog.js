Ext.define('Ext.locale.cs.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "Maximalizovat na celou obrazovku"
        },
        restoreTool: {
            tooltip: "Obnovit původní velikost"
        }
    }
});
