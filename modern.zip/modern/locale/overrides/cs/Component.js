Ext.define("Ext.locale.cs.Component", {
    override: "Ext.Component"
});
