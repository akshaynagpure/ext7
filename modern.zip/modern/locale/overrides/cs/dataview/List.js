Ext.define('Ext.locale.cs.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Prosím čekejte...'
    }
});
