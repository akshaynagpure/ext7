Ext.define('Ext.locale.cs.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Načíst další ...',
        noMoreRecordsText: 'Žádné další záznamy'
    }
});
