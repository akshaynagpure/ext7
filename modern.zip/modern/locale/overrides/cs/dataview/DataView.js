Ext.define("Ext.locale.cs.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "žádná data k zobrazení"
    }
});
