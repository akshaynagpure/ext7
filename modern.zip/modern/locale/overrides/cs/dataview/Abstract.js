Ext.define('Ext.locale.cs.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Prosím čekejte...'
    }
});
