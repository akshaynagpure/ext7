Ext.define('Ext.locale.cs.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'Žádná data k zobrazení'
    }
});
