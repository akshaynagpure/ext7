Ext.define("Ext.locale.cs.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: 'Prosím čekejte...'
    }
});
