Ext.define("Ext.locale.cs.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: 'Archiv...'
    }
});
