Ext.define('Ext.locale.cs.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Toto pole je povinné',
        validationMessage: 'je ve špatném formátu'
    }
});
