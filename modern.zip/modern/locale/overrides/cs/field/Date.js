Ext.define('Ext.locale.cs.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'Datum v tomto poli nesmí být starší než {0}',
    maxDateMessage: 'Datum v tomto poli nesmí být novější než {0}'
});
