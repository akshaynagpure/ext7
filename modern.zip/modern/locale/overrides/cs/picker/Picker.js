Ext.define('Ext.locale.cs.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'Hotovo',
        cancelButton: 'Storno'
    }
});
