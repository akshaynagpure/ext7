Ext.define('Ext.locale.cs.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'Hotovo',
        monthText: 'Měsíc',
        dayText: 'Den',
        yearText: 'Rok'
    }
});
