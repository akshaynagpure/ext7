// This is needed until we can refactor all of the locales into individual files
Ext.define("Ext.locale.fi.Component", {
    override: "Ext.Component"
});
