Ext.define('Ext.locale.fi.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Ladataan...'
    }
});
