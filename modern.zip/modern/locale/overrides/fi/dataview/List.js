Ext.define('Ext.locale.fi.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Ladataan...'
    }
});
