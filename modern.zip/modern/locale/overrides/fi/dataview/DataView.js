Ext.define("Ext.locale.fi.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "tietoja ei näytetä"
    }
});
