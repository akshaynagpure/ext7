Ext.define('Ext.locale.fi.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Lataa lisää ...',
        noMoreRecordsText: 'ei muita tallenteita'
    }
});
