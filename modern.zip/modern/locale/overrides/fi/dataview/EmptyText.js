Ext.define('Ext.locale.fi.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'Ei näytettäviä tietoja'
    }
});
