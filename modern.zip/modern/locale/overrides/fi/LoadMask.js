Ext.define("Ext.locale.fi.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: 'Ladataan...'
    }
});
