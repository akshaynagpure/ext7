Ext.define('Ext.locale.fi.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "Sulje paneeli",
        expandToolText: "Laajenna paneeli"
    }
});
