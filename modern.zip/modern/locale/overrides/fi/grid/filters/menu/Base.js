Ext.define("Ext.locale.fi.grid.filters.menu.Base", {
    override: "Ext.grid.filters.menu.Base",

    config: {
        text: "Suodatin"
    }
});
