Ext.define("Ext.locale.fi.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} rivi(ä) valittu"
});
