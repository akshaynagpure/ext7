Ext.define("Ext.locale.fi.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "Sarakkeet"
    }
});
