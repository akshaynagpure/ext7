Ext.define("Ext.locale.fi.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "Järjestä Ö-A"
    }
});
