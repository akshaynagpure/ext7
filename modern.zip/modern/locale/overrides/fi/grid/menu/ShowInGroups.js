Ext.define("Ext.locale.fi.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "Näytä ryhmissä"
    }
});
