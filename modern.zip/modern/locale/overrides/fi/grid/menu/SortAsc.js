Ext.define("Ext.locale.fi.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "Järjestä A-Ö"
    }
});
