Ext.define("Ext.locale.fi.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "Ryhmä tähän"
    }
});
