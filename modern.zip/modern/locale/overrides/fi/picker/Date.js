Ext.define('Ext.locale.nl.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'valmis',
        monthText: 'Kuukausi',
        dayText: 'päivä',
        yearText: 'vuosi'
    }
});
