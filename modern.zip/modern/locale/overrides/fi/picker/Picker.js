Ext.define('Ext.locale.fi.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: '',
        cancelButton: 'Peruuta'
    }
});
