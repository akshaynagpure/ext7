Ext.define('Ext.locale.fi.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Ei ole kelvollinen numero'
    }
});
