Ext.define('Ext.locale.fi.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Ei ole kelvollinen valuutan määrä'
    }
});
