Ext.define('Ext.locale.fi.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'Sillä on väärä muoto'
    }
});
