Ext.define('Ext.locale.fi.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Ei ole kelvollinen puhelinnumero'
    }
});
