Ext.define('Ext.locale.fi.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'Onko arvo jätetty pois'
    }
});
