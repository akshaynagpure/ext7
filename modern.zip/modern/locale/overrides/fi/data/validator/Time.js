Ext.define('Ext.locale.fi.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Ei ole kelvollinen kellonaika'
    }
});
