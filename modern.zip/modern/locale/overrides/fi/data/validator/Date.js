Ext.define('Ext.locale.fi.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "Ei ole kelvollinen päivämäärä"
    }
});
