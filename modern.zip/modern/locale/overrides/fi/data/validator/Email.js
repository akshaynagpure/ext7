Ext.define('Ext.locale.fi.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Ei ole kelvollinen sähköpostiosoite'
    }
});
