Ext.define('Ext.locale.fi.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Ei ole kelvollinen URL-osoite'
    }
});
