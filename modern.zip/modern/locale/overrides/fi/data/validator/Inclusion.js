Ext.define('Ext.locale.fi.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Se ei ole hyväksyttävien arvojen luettelossa'
    }
});
