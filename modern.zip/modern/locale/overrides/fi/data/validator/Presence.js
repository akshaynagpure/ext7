Ext.define('Ext.locale.fi.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: 'On oltava läsnä'
    }
});
