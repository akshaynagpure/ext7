Ext.define('Ext.locale.fi.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Ei ole kelvollinen päivämäärä ja kellonaika'
    }
});
