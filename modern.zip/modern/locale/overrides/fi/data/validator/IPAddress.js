Ext.define('Ext.locale.fi.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Ei ole kelvollinen IP-osoite'
    }
});
