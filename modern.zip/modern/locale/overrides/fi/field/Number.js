Ext.define('Ext.locale.fi.field.Number', {
    override: 'Ext.field.Number',

    decimalsText: 'Suurin desimaaliluku on (0)',
    minValueText: 'Tämän kentän pienin sallittu arvo on {0}',
    maxValueText: 'Tämän kentän suurin sallittu arvo on {0}',
    badFormatMessage: '{0} ei ole numero'
});
