Ext.define('Ext.locale.fi.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Tämä kenttä on pakollinen',
        validationMessage: 'on väärässä muodossa'
    }
});
