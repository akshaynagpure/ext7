Ext.define('Ext.locale.fi.field.Text', {
    override: 'Ext.field.Text',

    badFormatMessage: 'Arvo ei vastaa vaadittua muotoa',
    config: {
        requiredMessage: 'Tämä kenttä on pakollinen',
        validationMessage: 'on väärässä muodossa'
    }
});
