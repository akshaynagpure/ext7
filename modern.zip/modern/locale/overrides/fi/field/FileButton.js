Ext.define("Ext.locale.fi.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: 'arkisto ...'
    }
});
