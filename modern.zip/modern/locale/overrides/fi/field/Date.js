Ext.define('Ext.locale.fi.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'Tämän kentän päivämäärän tulee olla {0} jälkeen',
    maxDateMessage: 'Tämän kentän päivämäärän tulee olla ennen {0}'
});
