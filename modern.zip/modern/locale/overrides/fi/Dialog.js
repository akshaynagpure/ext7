Ext.define('Ext.locale.fi.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "Maksimoi koko näyttöön"
        },
        restoreTool: {
            tooltip: "Palauta alkuperäiseen kokoon"
        }
    }
});
