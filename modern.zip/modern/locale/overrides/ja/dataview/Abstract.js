Ext.define('Ext.locale.ja.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: '読み込み中...'
    }
});
