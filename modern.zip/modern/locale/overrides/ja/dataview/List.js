Ext.define('Ext.locale.ja.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: '読み込み中...'
    }
});
