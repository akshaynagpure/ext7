Ext.define("Ext.locale.ja.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "表示するデータがありません"
    }
});
