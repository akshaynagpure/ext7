Ext.define('Ext.locale.ja.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'さらに読み込む...',
        noMoreRecordsText: 'これ以上レコードがない'
    }
});
