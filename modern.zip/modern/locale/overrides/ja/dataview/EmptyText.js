Ext.define('Ext.locale.ja.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: '表示するデータがありません'
    }
});
