Ext.define('Ext.locale.ja.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'done',
        monthText: '月',
        dayText: '日',
        yearText: '年'
    }
});
