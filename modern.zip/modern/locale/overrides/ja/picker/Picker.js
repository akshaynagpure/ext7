Ext.define('Ext.locale.ja.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'done',
        cancelButton: 'キャンセル'
    }
});
