Ext.define('Ext.locale.ja.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: '数字ではありません'
    }
});
