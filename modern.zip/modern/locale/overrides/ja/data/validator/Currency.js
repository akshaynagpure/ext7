Ext.define('Ext.locale.ja.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: '有効な通貨金額ではありません'
    }

});
