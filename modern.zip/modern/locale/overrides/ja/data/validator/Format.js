Ext.define('Ext.locale.ja.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'フォーマットが違います'
    }
});
