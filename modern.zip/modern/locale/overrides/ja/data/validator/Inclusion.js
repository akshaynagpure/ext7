Ext.define('Ext.locale.ja.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: '許容値のリストに含まれていません'
    }
});
