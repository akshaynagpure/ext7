Ext.define('Ext.locale.ja.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: '有効なCIDRブロックではありません'
    }
});
