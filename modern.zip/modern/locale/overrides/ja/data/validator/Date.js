Ext.define('Ext.locale.ja.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "有効な日付ではありません"
    }
});
