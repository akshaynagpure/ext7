Ext.define('Ext.locale.ja.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: '有効なURLではありません'
    }
});
