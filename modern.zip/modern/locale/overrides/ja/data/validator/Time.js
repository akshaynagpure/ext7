Ext.define('Ext.locale.ja.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: '有効な時間ではありません'
    }
});
