Ext.define('Ext.locale.ja.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: '有効なIPアドレスではありません'
    }
});
