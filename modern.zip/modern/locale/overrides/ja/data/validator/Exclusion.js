Ext.define('Ext.locale.ja.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: '除外された値です'
    }
});
