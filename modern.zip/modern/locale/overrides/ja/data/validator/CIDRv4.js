Ext.define('Ext.locale.ja.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: '有効なCIDRブロックではありません'
    }
});
