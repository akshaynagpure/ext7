Ext.define('Ext.locale.ja.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: '有効な日時ではありません'
    }
});
