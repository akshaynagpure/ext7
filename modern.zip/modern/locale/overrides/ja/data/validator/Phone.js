Ext.define('Ext.locale.ja.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: '有効な電話番号ではありません'
    }
});
