Ext.define('Ext.locale.ja.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: '有効なメールアドレスではありません'
    }
});
