Ext.define('Ext.locale.ja.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: '存在している必要があります'
    }
});
