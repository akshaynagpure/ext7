Ext.define('Ext.locale.ja.field.Number', {
    override: 'Ext.field.Number',

    decimalsText: 'このフィールドの最小値は {0} です。',
    minValueText: 'このフィールドの最小値は {0} です。',
    maxValueText: 'このフィールドの最大値は {0} です。',
    badFormatMessage: '{0} は数値ではありません。'
});
