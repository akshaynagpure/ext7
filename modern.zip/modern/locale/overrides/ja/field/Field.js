Ext.define('Ext.locale.ja.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'このフィールドは必須です',
        validationMessage: '形式が間違っています'
    }
});
