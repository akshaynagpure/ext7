Ext.define("Ext.locale.ja.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: '参照...'
    }
});
