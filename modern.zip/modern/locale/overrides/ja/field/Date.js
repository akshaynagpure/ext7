Ext.define('Ext.locale.ja.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'このフィールドの日付は、 {0} 以降の日付に設定してください。',
    maxDateMessage: 'このフィールドの日付は、 {0} 以前の日付に設定してください。'
});
