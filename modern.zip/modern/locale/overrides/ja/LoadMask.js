Ext.define("Ext.locale.ja.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: '読み込み中...'
    }
});
