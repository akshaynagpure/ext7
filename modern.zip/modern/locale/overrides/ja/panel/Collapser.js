Ext.define('Ext.locale.ja.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "パネルを閉じる",
        expandToolText: "パネルを開く"
    }
});
