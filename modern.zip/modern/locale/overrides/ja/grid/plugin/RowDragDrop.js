Ext.define("Ext.locale.ja.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} 行選択"
});
