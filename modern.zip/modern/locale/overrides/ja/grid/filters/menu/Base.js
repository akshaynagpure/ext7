Ext.define("Ext.locale.ja.grid.filters.menu.Base", {
    override: "Ext.grid.filters.menu.Base",

    config: {
        text: "フィルタ"
    }
});
