Ext.define("Ext.locale.ja.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "グループで表示"
    }
});
