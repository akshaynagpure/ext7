Ext.define("Ext.locale.ja.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "カラム"
    }
});
