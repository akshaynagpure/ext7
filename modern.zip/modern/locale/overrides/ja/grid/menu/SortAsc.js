Ext.define("Ext.locale.ja.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "昇順"
    }
});
