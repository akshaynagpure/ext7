Ext.define("Ext.locale.ja.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "降順"
    }
});
