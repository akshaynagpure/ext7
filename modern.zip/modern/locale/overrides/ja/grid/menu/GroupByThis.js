Ext.define("Ext.locale.ja.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "これでグループ化する"
    }
});
