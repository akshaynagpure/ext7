Ext.define('Ext.locale.ru.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: 'Свернуть панель',
        expandToolText: 'Развернуть панель'
    }
});
