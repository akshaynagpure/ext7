Ext.define('Ext.locale.ru.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'Выполнить',
        cancelButton: 'Отмена'
    }
});
