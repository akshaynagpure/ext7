Ext.define('Ext.locale.ru.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'Готово',
        monthText: 'Месяц',
        dayText: 'День',
        yearText: 'Год'
    }
});
