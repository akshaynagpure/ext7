Ext.define('Ext.locale.ru.LoadMask', {
    override: 'Ext.LoadMask',

    config: {
        message: 'Загрузка...'
    }
});
