Ext.define('Ext.locale.ru.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Загрузка...'
    }
});
