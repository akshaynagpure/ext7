Ext.define('Ext.locale.ru.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'Нет данных'
    }
});
