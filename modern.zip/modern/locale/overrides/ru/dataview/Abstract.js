Ext.define('Ext.locale.ru.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Загрузка...'
    }
});
