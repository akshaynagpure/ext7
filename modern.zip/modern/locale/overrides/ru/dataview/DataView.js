Ext.define('Ext.locale.ru.dataview.DataView', {
    override: 'Ext.dataview.DataView',

    config: {
        emptyText: ''
    }
});
