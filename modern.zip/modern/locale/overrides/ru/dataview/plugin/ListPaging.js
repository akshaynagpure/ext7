Ext.define('Ext.locale.ru.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Загрузить больше...',
        noMoreRecordsText: 'Больше нет записей'
    }
});
