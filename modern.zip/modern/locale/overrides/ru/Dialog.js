Ext.define('Ext.locale.ru.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: 'Развернуть на весь экран'
        },
        restoreTool: {
            tooltip: 'Восстановить исходный размер'
        }
    }
});
