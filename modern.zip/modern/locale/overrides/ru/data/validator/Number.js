Ext.define('Ext.locale.ru.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Недопустимый формат числа'
    }
});
