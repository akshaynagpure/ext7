Ext.define('Ext.locale.ru.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'Значение является исключенным'
    }
});
