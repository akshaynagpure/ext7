Ext.define('Ext.locale.ru.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: 'Недопустимый формат блока CIDR'
    }
});
