Ext.define('Ext.locale.ru.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'Недопустимый формат'
    }
});
