Ext.define('Ext.locale.ru.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Некорректный IP-адрес'
    }
});
