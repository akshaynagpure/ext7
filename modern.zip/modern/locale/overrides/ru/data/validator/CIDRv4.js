Ext.define('Ext.locale.ru.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: 'Недопустимый формат блока CIDR'
    }
});
