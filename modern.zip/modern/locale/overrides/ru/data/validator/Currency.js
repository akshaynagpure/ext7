Ext.define('Ext.locale.ru.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Недопустимая денежная сумма'
    }
});
