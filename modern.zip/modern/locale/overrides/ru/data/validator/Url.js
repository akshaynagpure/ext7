Ext.define('Ext.locale.ru.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Недопустимый URL-адрес'
    }
});
