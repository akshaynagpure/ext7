Ext.define('Ext.locale.ru.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Значение отсутствует в списке допустимых'
    }
});
