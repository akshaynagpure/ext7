Ext.define('Ext.locale.ru.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: 'Обязательно к заполнению'
    }
});
