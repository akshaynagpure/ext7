Ext.define('Ext.locale.ru.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Недопустимый адрес электронной почты'
    }
});
