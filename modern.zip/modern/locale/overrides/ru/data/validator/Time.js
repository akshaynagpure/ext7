Ext.define('Ext.locale.ru.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Некорректный формат времени'
    }
});
