Ext.define('Ext.locale.ru.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Недопустимые дата и время'
    }
});
