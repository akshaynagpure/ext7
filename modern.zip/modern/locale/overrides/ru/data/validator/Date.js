Ext.define('Ext.locale.ru.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: 'Некорректный формат даты'
    }
});
