Ext.define('Ext.locale.ru.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Недопустимый номер телефона'
    }
});
