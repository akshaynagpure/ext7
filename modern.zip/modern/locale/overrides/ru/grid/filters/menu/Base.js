Ext.define("Ext.locale.ru.grid.filters.menu.Base", {
    override: "Ext.grid.filters.menu.Base",

    config: {
        text: "Фильтр"
    }
});
