Ext.define("Ext.locale.ru.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} выбранных строк"
});
