Ext.define('Ext.locale.ru.grid.menu.ShowInGroups', {
    override: 'Ext.grid.menu.ShowInGroups',

    config: {
        text: 'Показать в группах'
    }
});
