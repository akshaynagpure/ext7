Ext.define('Ext.locale.ru.grid.menu.SortAsc', {
    override: 'Ext.grid.menu.SortAsc',

    config: {
        text: 'Сортировать по возрастанию'
    }
});
