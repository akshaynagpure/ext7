Ext.define('Ext.locale.ru.grid.menu.GroupByThis', {
    override: 'Ext.grid.menu.GroupByThis',

    config: {
        text: 'Группировать по этому полю'
    }
});
