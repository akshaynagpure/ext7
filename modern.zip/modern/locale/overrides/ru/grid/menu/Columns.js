Ext.define('Ext.locale.ru.grid.menu.Columns', {
    override: 'Ext.grid.menu.Columns',

    config: {
        text: 'Столбцы'
    }
});
