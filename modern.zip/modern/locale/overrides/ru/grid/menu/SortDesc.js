Ext.define('Ext.locale.ru.grid.menu.SortDesc', {
    override: 'Ext.grid.menu.SortDesc',

    config: {
        text: 'Сортировать по убыванию'
    }
});
