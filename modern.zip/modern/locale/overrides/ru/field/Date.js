Ext.define('Ext.locale.ru.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'Дата в этом поле должна быть равна или позже {0}',
    maxDateMessage: 'Дата в этом поле должна быть равна или раньше {0}'
});
