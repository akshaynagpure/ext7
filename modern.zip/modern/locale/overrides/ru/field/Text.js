Ext.define('Ext.locale.ru.field.Text', {
    override: 'Ext.field.Text',

    badFormatMessage: 'Недопустимый формат значения',
    config: {
        requiredMessage: 'Это поле обязательно для заполнения',
        validationMessage: 'Недопустимый формат'
    }
});
