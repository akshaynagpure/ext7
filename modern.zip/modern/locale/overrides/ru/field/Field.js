Ext.define('Ext.locale.ru.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Это поле обязательно для заполнения',
        validationMessage: 'Недопустимый формат'
    }
});
