Ext.define('Ext.locale.ru.field.FileButton', {
    override: 'Ext.field.FileButton',

    config: {
        text: 'Обзор...'
    }
});
