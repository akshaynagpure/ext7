Ext.define('Ext.locale.da.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'Er en værdi, der er udelukket'
    }
});
