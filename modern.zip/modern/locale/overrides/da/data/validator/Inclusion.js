Ext.define('Ext.locale.da.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Det står ikke i listen med acceptable værdier'
    }
});
