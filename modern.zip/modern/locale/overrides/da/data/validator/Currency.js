Ext.define('Ext.locale.da.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Er ikke et gyldigt valuta beløb'
    }
});
