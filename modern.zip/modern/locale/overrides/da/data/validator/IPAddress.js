Ext.define('Ext.locale.da.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Er ikke en gyldig IP-adresse'
    }
});
