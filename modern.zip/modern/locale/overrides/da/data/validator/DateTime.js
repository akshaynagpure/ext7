Ext.define('Ext.locale.da.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Er ikke en gyldig dato og klokkeslæt'
    }
});
