Ext.define('Ext.locale.da.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Er ikke en gyldig email-adresse'
    }
});
