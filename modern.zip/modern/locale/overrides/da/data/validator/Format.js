Ext.define('Ext.locale.da.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'Det har det forkerte format'
    }
});
