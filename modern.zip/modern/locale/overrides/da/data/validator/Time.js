Ext.define('Ext.locale.da.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Er ikke en gyldig tid'
    }
});
