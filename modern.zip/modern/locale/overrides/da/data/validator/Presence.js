Ext.define('Ext.locale.da.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: 'Skal være til stede'
    }
});
