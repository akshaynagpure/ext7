Ext.define('Ext.locale.da.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "Er ikke en gyldig dato"
    }
});
