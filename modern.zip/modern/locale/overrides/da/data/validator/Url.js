Ext.define('Ext.locale.da.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Er ikke en gyldig webadresse'
    }
});
