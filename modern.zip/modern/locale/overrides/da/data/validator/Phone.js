Ext.define('Ext.locale.da.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Er ikke et gyldigt telefonnummer'
    }
});
