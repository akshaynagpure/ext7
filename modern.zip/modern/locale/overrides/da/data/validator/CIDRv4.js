Ext.define('Ext.locale.da.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: 'Er ikke en gyldig CIDR-blok'
    }
});
