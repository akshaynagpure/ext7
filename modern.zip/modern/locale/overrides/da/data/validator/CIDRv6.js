Ext.define('Ext.locale.da.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: 'Er ikke en gyldig CIDR-blok'
    }
});
