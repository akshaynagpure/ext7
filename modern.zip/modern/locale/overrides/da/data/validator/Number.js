Ext.define('Ext.locale.da.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Er ikke et gyldigt nummer'
    }
});
