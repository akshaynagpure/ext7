Ext.define("Ext.locale.da.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: 'Henter...'
    }
});
