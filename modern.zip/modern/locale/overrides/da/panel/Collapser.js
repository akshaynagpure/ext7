Ext.define('Ext.locale.da.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "Luk panel",
        expandToolText: "Udvid panel"
    }
});
