Ext.define("Ext.locale.da.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: 'Arkiv ...'
    }
});
