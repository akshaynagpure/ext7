Ext.define('Ext.locale.da.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Dette felt er påkrævet',
        validationMessage: 'er i forkert format'
    }
});
