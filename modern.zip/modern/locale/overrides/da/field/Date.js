Ext.define('Ext.locale.da.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'Datoen i dette felt skal være efter {0}',
    maxDateMessage: 'Datoen i dette felt skal være før {0}'
});
