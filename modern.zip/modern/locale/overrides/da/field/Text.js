Ext.define('Ext.locale.da.field.Text', {
    override: 'Ext.field.Text',

    badFormatMessage: 'Værdien stemmer ikke overens med det krævede format',
    config: {
        requiredMessage: 'Dette felt er påkrævet',
        validationMessage: 'er i forkert format'
    }
});
