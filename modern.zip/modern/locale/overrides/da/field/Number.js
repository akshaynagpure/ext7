Ext.define('Ext.locale.da.field.Number', {
    override: 'Ext.field.Number',

    decimalsText: 'Det maksimale decimaltal er (0)',
    minValueText: 'Mindste-værdien for dette felt er {0}',
    maxValueText: 'Maksimum-værdien for dette felt er {0}',
    badFormatMessage: '{0} er ikke et tilladt nummer'
});
