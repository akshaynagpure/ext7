Ext.define("Ext.locale.da.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "Vis i grupper"
    }
});
