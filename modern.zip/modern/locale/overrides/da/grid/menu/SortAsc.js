Ext.define("Ext.locale.da.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "Sortér stigende"
    }
});
