Ext.define("Ext.locale.da.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "Sortér faldende"
    }
});
