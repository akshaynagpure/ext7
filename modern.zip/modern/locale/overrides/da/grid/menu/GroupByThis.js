Ext.define("Ext.locale.da.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "Gruppér ved dette"
    }
});
