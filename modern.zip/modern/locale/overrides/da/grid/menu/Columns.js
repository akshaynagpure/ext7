Ext.define("Ext.locale.da.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "Kolonner"
    }
});
