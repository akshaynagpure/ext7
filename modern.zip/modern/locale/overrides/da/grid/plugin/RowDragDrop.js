Ext.define("Ext.locale.da.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} markerede rækker"
});
