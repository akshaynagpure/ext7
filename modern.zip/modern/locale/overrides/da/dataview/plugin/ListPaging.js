Ext.define('Ext.locale.da.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Indlæs mere ...',
        noMoreRecordsText: 'Ingen flere poster'
    }
});
