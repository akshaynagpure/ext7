Ext.define('Ext.locale.da.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Henter...'
    }
});
