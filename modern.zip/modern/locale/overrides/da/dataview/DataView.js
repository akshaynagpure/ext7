Ext.define("Ext.locale.da.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "ingen data at viseingen data at vise"
    }
});
