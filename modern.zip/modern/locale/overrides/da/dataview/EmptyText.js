Ext.define('Ext.locale.da.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'ingen data at vise'
    }
});
