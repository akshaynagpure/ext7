Ext.define('Ext.locale.da.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Henter...'
    }
});
