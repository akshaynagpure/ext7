Ext.define('Ext.locale.nl.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'Færdig',
        monthText: 'Måned',
        dayText: 'Dag',
        yearText: 'år'
    }
});
