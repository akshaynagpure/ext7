Ext.define('Ext.locale.da.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'Færdig',
        cancelButton: 'Afbestille'
    }
});
