Ext.define('Ext.locale.da.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "Maksimer til fuldskærm"
        },
        restoreTool: {
            tooltip: "Gendan til originalstørrelse"
        }
    }
});
