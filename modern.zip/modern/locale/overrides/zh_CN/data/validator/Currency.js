Ext.define('Ext.locale.zh_CN.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: '不是有效的货币金额'
    }
});
