Ext.define('Ext.locale.zh_CN.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: '不是有效的电话号码'
    }
});
