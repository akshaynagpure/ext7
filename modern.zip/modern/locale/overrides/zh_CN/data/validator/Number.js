Ext.define('Ext.locale.zh_CN.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: '不是有效的数字'
    }
});
