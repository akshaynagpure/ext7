Ext.define('Ext.locale.zh_CN.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: '它不在可接受值的列表中'
    }
});
