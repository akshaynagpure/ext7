Ext.define('Ext.locale.zh_CN.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: '不是有效的日期和时间'
    }
});
