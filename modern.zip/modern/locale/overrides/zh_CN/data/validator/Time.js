Ext.define('Ext.locale.zh_CN.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: '不是有效的时间'
    }
});
