Ext.define('Ext.locale.zh_CN.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: '不是有效的CIDR块'
    }
});
