Ext.define('Ext.locale.zh_CN.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: '必须在场'
    }
});
