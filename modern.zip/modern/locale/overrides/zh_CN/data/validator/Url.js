Ext.define('Ext.locale.zh_CN.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: '不是有效的URL'
    }
});
