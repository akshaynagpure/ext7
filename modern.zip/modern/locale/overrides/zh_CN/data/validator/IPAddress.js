Ext.define('Ext.locale.zh_CN.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: '不是有效的IP地址'
    }
});
