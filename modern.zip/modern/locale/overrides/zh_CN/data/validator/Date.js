Ext.define('Ext.locale.zh_CN.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "不是有效日期"
    }
});
