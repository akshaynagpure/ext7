Ext.define('Ext.locale.zh_CN.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: '它的格式不对'
    }
});
