Ext.define('Ext.locale.zh_CN.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: '不是有效的电子邮件地址'
    }
});
