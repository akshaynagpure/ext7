Ext.define('Ext.locale.zh_CN.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: '是已排除的值'
    }
});
