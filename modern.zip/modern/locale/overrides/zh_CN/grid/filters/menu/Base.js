Ext.define("Ext.locale.zh_CN.grid.filters.menu.Base", {
    override: "Ext.grid.filters.menu.Base",

    config: {
        text: "过滤器"
    }
});
