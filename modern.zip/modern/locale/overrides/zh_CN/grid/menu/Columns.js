Ext.define("Ext.locale.zh_CN.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        // update
        text: "列"
    }
});
