Ext.define('Ext.locale.zh_CN.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: '没有数据显示'
    }
});
