Ext.define('Ext.locale.zh_CN.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: '读取中...'
    }
});
