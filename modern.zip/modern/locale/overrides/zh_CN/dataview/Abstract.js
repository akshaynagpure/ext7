Ext.define('Ext.locale.zh_CN.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: '读取中...'
    }
});
