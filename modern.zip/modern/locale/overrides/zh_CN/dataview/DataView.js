Ext.define("Ext.locale.zh_CN.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "没有要显示的数据"
    }
});
