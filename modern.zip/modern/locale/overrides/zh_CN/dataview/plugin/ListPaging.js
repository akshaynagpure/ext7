Ext.define('Ext.locale.zh_CN.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: '加载更多...',
        noMoreRecordsText: '没有更多记录'
    }
});
