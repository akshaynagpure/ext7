Ext.define('Ext.locale.zh_CN.ux.colorpick.Selector', {
    override: 'Ext.ux.colorpick.Selector',

    okButtonText: '确定',
    cancelButtonText: '取消'
});
