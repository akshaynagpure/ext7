Ext.define('Ext.locale.zh_CN.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "最大化到全屏"
        },
        restoreTool: {
            tooltip: "恢复到原始大小"
        }
    }
});
