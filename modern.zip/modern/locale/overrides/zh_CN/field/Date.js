Ext.define('Ext.locale.zh_CN.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: '此字段中的日期必须在 {0} 之后',
    maxDateMessage: '此字段中的日期必须为 {0}'
});
