Ext.define('Ext.locale.zh_CN.field.Text', {
    override: 'Ext.field.Text',

    badFormatMessage: '值与所需格式不匹配',
    config: {
        requiredMessage: '此字段是必填字段',
        validationMessage: '格式错误'
    }
});
