Ext.define('Ext.locale.zh_CN.field.Number', {
    override: 'Ext.field.Number',

    decimalsText: '最大十进制数 (0)',
    minValueText: '该输入项的最小值是 {0}',
    maxValueText: '该输入项的最大值是 {0}',
    badFormatMessage: '{0} 不是有效数值'
});
