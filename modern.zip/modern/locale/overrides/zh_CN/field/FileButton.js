Ext.define("Ext.locale.zh_CN.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: '评论......'
    }
});
