Ext.define('Ext.locale.zh_CN.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: '此字段是必填字段',
        validationMessage: '格式错误'
    }
});
