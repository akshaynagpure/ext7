Ext.define('Ext.locale.nl.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Is geen geldig IP-adres'
    }
});
