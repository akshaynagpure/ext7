Ext.define('Ext.locale.nl.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Het staat niet in de lijst met aanvaardbare waarden'
    }
});
