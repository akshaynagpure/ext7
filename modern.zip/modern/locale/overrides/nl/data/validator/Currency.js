Ext.define('Ext.locale.nl.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Is geen geldig valutabedrag'
    }
});
