Ext.define('Ext.locale.nl.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: 'Moet aanwezig zijn'
    }
});
