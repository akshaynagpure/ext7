Ext.define('Ext.locale.nl.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Is geen geldig nummer'
    }
});
