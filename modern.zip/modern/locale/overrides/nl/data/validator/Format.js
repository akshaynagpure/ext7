Ext.define('Ext.locale.nl.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'Het heeft de verkeerde indeling'
    }
});
