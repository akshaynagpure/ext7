Ext.define('Ext.locale.nl.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Is geen geldige datum en tijd'
    }
});
