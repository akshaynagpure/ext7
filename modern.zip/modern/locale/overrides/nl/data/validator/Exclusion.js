Ext.define('Ext.locale.nl.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'Is een waarde die is uitgesloten'
    }
});
