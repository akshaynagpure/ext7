Ext.define('Ext.locale.nl.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "Is geen geldige datum"
    }
});
