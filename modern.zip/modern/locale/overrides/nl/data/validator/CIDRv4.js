Ext.define('Ext.locale.nl.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: 'Is geen geldig CIDR-blok'
    }
});
