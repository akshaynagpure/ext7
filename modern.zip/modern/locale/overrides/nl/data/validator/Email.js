Ext.define('Ext.locale.nl.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Is geen geldig e-mailadres'
    }
});
