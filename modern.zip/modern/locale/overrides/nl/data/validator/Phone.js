Ext.define('Ext.locale.nl.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Is geen geldig telefoonnummer'
    }
});
