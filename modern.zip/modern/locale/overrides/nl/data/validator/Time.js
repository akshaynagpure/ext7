Ext.define('Ext.locale.nl.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Is geen geldige tijd'
    }
});
