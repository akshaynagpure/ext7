Ext.define('Ext.locale.nl.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: 'Is geen geldig CIDR-blok'
    }
});
