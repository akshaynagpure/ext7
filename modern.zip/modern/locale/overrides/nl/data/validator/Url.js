Ext.define('Ext.locale.nl.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Is geen geldige URL'
    }
});
