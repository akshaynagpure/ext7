Ext.define('Ext.locale.nl.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'Gedaan',
        cancelButton: 'Annuleren'
    }
});
