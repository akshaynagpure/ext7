Ext.define('Ext.locale.nl.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'Gedaan',
        monthText: 'Maand',
        dayText: 'Dag',
        yearText: 'Jaar'
    }
});
