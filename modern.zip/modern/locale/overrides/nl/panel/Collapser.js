Ext.define('Ext.locale.nl.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "Venster sluiten",
        expandToolText: "paneel Uitvouwen"
    }
});
