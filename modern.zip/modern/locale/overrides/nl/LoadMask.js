Ext.define("Ext.locale.nl.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: 'Bezig met laden...'
    }
});
