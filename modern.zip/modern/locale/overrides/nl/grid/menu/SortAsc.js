Ext.define("Ext.locale.nl.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "Sorteer oplopend"
    }
});
