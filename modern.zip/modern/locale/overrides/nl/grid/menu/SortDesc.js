Ext.define("Ext.locale.nl.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "Sorteer aflopend"
    }
});
