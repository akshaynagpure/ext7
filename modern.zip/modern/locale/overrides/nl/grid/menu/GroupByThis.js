Ext.define("Ext.locale.nl.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "Groepeer op deze manier"
    }
});
