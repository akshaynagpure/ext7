Ext.define("Ext.locale.nl.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "Weergeven in groepen"
    }
});
