Ext.define("Ext.locale.nl.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "Kolommen"
    }
});
