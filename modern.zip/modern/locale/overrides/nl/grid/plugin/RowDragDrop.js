Ext.define("Ext.locale.nl.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: '{0} geselecteerde rij(en)'
});
