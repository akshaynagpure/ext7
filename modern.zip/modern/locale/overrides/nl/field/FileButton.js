Ext.define("Ext.locale.nl.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: 'Archief...'
    }
});
