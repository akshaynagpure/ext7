Ext.define('Ext.locale.nl.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'De datum in dit veld moet na {0} liggen',
    maxDateMessage: 'De datum in dit veld moet voor {0} liggen'
});
