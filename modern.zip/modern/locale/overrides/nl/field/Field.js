Ext.define('Ext.locale.nl.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Dit veld is verplicht',
        validationMessage: 'heeft de verkeerde indeling'
    }
});
