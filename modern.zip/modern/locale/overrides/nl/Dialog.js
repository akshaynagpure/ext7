Ext.define('Ext.locale.nl.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "Maximaliseren naar volledig scherm"
        },
        restoreTool: {
            tooltip: "herstellen naar origineel formaat"
        }
    }
});
