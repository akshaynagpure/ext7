Ext.define('Ext.locale.nl.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Bezig met laden...'
    }
});
