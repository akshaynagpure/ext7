Ext.define('Ext.locale.nl.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Meer laden',
        noMoreRecordsText: 'geen records meer opnemen'
    }
});
