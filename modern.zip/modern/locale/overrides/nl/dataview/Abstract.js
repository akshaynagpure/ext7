Ext.define('Ext.locale.nl.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Bezig met laden...'
    }
});
