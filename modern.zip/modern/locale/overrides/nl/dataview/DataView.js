Ext.define("Ext.locale.nl.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "geen gegevens om weer te geven"
    }
});
