Ext.define('Ext.locale.nl.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'geen gegevens om weer te geven'
    }
});
