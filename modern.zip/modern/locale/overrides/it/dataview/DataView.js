Ext.define("Ext.locale.it.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "nessun dato da visualizzare"
    }
});
