Ext.define('Ext.locale.it.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'Nessun dato da visualizzare'
    }
});
