Ext.define('Ext.locale.it.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Carica di più...',
        noMoreRecordsText: 'Nessun dato'
    }
});
