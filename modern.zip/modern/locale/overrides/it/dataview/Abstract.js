Ext.define('Ext.locale.it.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Caricamento...'
    }
});
