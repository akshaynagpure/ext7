Ext.define('Ext.locale.it.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Caricamento...'
    }
});
