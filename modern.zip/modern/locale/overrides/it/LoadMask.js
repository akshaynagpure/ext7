Ext.define("Ext.locale.it.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: 'Caricamento...'
    }
});
