Ext.define('Ext.locale.it.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Non è un indirizzo IP valido'
    }
});
