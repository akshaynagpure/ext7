Ext.define('Ext.locale.it.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "Data non valida"
    }
});
