Ext.define('Ext.locale.it.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Non è un indirizzo email valido'
    }
});
