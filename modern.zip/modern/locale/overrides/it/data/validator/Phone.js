Ext.define('Ext.locale.it.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Non è un numero di telefono valido'
    }
});
