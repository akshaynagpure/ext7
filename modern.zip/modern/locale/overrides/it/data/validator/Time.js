Ext.define('Ext.locale.it.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Non è un tempo valido'
    }
});
