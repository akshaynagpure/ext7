Ext.define('Ext.locale.it.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Non sta nella lista dei valori validi'
    }
});
