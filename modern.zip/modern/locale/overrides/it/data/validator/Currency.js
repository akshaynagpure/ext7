Ext.define('Ext.locale.it.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Importo valuta non valido'
    }

});
