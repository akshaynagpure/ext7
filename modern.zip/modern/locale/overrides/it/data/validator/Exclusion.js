Ext.define('Ext.locale.it.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'È un valore che è stato escluso'
    }
});
