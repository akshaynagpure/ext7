Ext.define('Ext.locale.it.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: 'Non è un CIDR block valido'
    }
});
