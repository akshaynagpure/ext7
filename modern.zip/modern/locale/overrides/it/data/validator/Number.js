Ext.define('Ext.locale.it.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Non è un numero valido'
    }
});
