Ext.define('Ext.locale.it.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: 'Non è un CIDR block valido'
    }
});
