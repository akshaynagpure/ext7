Ext.define('Ext.locale.it.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'È nel formato sbagliato'
    }
});
