Ext.define('Ext.locale.it.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Data e orario non valido'
    }
});
