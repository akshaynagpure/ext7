Ext.define('Ext.locale.it.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Non è un url valido'
    }
});
