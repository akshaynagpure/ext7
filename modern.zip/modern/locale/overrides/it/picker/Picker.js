Ext.define('Ext.locale.it.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'Fatto',
        cancelButton: 'Cancella'
    }
});
