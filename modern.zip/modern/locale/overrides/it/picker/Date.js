Ext.define('Ext.locale.it.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'Pronto',
        monthText: 'Mese',
        dayText: 'Giorno',
        yearText: 'Anno'
    }
});
