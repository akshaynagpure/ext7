Ext.define('Ext.locale.it.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'La data in questo campo deve essere uguale o successivo a {0}',
    maxDateMessage: 'La data in questo campo deve essere uguale o precedente a {0}'
});
