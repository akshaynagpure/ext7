Ext.define('Ext.locale.it.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Questo campo è obbligatorio',
        validationMessage: 'È nel formato sbagliato'
    }
});
