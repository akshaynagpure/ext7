Ext.define("Ext.locale.it.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: 'Navigare...'
    }
});
