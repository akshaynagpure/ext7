Ext.define('Ext.locale.it.field.Number', {
    override: 'Ext.field.Number',

    decimalsText: 'El número máximo de decimales es  {0}',
    minValueText: 'Il valore minimo per questo campo è {0}',
    maxValueText: 'Il valore massimo per questo campo è {0}',
    badFormatMessage: 'Il valore non è un numero valido'
});
