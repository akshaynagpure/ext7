Ext.define('Ext.locale.it.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "Riduci pannello",
        expandToolText: "Espandi pannello"
    }
});
