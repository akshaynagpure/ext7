Ext.define("Ext.locale.it.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "Colonne"
    }
});
