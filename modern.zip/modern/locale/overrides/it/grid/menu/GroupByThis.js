Ext.define("Ext.locale.it.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "Raggruppa per questo campo"
    }
});
