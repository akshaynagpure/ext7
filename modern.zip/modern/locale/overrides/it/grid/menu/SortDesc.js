Ext.define("Ext.locale.it.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "Ordine decrescente"
    }
});
