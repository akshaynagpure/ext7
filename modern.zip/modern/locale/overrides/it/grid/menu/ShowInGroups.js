Ext.define("Ext.locale.it.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "Mostra in gruppi"
    }
});
