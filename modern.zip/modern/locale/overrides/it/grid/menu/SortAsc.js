Ext.define("Ext.locale.it.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "Ordine crescente"
    }
});
