Ext.define("Ext.locale.it.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} Righe selezionate"
});
