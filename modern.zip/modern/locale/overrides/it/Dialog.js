Ext.define('Ext.locale.it.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "Maksimer til fuldskærm"
        },
        restoreTool: {
            tooltip: "Gendan til originalstørrelse"
        }
    }
});
