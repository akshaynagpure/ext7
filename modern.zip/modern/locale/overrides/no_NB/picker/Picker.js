Ext.define('Ext.locale.no_NB.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        doneButton: 'done',
        cancelButton: 'Avbryt'
    }
});
