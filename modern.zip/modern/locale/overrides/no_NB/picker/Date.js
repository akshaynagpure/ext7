Ext.define('Ext.locale.no_NB.picker.Date', {
    override: 'Ext.picker.Date',

    config: {
        doneButton: 'done',
        monthText: 'Måned',
        dayText: 'Dag',
        yearText: 'ar'
    }
});
