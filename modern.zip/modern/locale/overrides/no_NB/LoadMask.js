Ext.define("Ext.locale.no_NB.LoadMask", {
    override: "Ext.LoadMask",

    config: {
        message: 'Laster...'
    }
});
