Ext.define('Ext.locale.no_NB.data.validator.CIDRv4', {
    override: 'Ext.data.validator.CIDRv4',

    config: {
        message: 'Er ikke en gyldig CIDR-blokk'
    }
});
