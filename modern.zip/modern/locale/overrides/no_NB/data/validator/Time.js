Ext.define('Ext.locale.no_NB.data.validator.Time', {
    override: 'Ext.data.validator.Time',

    config: {
        message: 'Er ikke en gyldig klokkeslett'
    }
});
