Ext.define('Ext.locale.no_NB.data.validator.CIDRv6', {
    override: 'Ext.data.validator.CIDRv6',

    config: {
        message: 'Er ikke en gyldig CIDR-blokk'
    }
});
