Ext.define('Ext.locale.no_NB.data.validator.Inclusion', {
    override: 'Ext.data.validator.Inclusion',

    config: {
        message: 'Det er ikke på listen over akseptable verdier'
    }
});
