Ext.define('Ext.locale.no_NB.data.validator.Number', {
    override: 'Ext.data.validator.Number',

    config: {
        message: 'Er ikke et gyldig nummer'
    }
});
