Ext.define('Ext.locale.no_NB.data.validator.Phone', {
    override: 'Ext.data.validator.Phone',

    config: {
        message: 'Er ikke et gyldig telefonnummer'
    }
});
