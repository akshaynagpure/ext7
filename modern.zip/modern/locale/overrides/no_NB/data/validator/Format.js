Ext.define('Ext.locale.no_NB.data.validator.Format', {
    override: 'Ext.data.validator.Format',

    config: {
        message: 'Den har feil format'
    }
});
