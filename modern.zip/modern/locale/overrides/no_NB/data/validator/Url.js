Ext.define('Ext.locale.no_NB.data.validator.Url', {
    override: 'Ext.data.validator.Url',

    config: {
        message: 'Er ikke en gyldig nettadresse'
    }
});
