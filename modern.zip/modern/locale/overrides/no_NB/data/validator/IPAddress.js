Ext.define('Ext.locale.no_NB.data.validator.IPAddress', {
    override: 'Ext.data.validator.IPAddress',

    config: {
        message: 'Er ikke en gyldig IP-adresse'
    }
});
