Ext.define('Ext.locale.no_NB.data.validator.Presence', {
    override: 'Ext.data.validator.Presence',

    config: {
        message: 'Må være tilstede'
    }
});
