Ext.define('Ext.locale.no_NB.data.validator.Currency', {
    override: 'Ext.data.validator.Currency',

    config: {
        message: 'Er ikke et gyldig valuta beløp'
    }
});
