Ext.define('Ext.locale.no_NB.data.validator.Exclusion', {
    override: 'Ext.data.validator.Exclusion',

    config: {
        message: 'Er en verdi som er utelukket'
    }
});
