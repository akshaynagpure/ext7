Ext.define('Ext.locale.no_NB.data.validator.Email', {
    override: 'Ext.data.validator.Email',

    config: {
        message: 'Er ikke en gyldig e-postadresse'
    }
});
