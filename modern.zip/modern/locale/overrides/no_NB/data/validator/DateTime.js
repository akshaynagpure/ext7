Ext.define('Ext.locale.no_NB.data.validator.DateTime', {
    override: 'Ext.data.validator.DateTime',

    config: {
        message: 'Er ikke gyldig dato og klokkeslett'
    }
});
