Ext.define('Ext.locale.no_NB.data.validator.Date', {
    override: 'Ext.data.validator.Date',

    config: {
        message: "Er ikke en gyldig dato"
    }
});
