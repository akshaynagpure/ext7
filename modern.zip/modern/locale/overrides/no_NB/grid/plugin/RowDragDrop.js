Ext.define("Ext.locale.no_NB.grid.plugin.RowDragDrop", {
    override: "Ext.grid.plugin.RowDragDrop",
    dragText: "{0} markert(e) rad(er)"
});
