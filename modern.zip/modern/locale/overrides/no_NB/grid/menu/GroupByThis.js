Ext.define("Ext.locale.no_NB.grid.menu.GroupByThis", {
    override: "Ext.grid.menu.GroupByThis",

    config: {
        text: "Gruppe av dette"
    }
});
