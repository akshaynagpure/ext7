Ext.define("Ext.locale.no_NB.grid.menu.ShowInGroups", {
    override: "Ext.grid.menu.ShowInGroups",

    config: {
        text: "Vis i grupper"
    }
});
