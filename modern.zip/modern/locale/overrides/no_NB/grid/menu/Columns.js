Ext.define("Ext.locale.no_NB.grid.menu.Columns", {
    override: "Ext.grid.menu.Columns",

    config: {
        text: "Kolonner"
    }
});
