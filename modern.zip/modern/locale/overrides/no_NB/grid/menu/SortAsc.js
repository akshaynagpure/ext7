Ext.define("Ext.locale.no_NB.grid.menu.SortAsc", {
    override: "Ext.grid.menu.SortAsc",

    config: {
        text: "Sorter stigende"
    }
});
