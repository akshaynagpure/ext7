Ext.define("Ext.locale.no_NB.grid.menu.SortDesc", {
    override: "Ext.grid.menu.SortDesc",

    config: {
        text: "Sorter synkende"
    }
});
