Ext.define('Ext.locale.no_NB.panel.Collapser', {
    override: 'Ext.panel.Collapser',

    config: {
        collapseToolText: "Lukk panel",
        expandToolText: "Utvid panel"
    }
});
