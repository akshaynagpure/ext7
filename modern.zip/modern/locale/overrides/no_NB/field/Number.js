Ext.define('Ext.locale.no_NB.field.Number', {
    override: 'Ext.field.Number',

    decimalsText: 'Maksimal desimaltall er (0)',
    minValueText: 'Den minste verdien for dette feltet er {0}',
    maxValueText: 'Den største verdien for dette feltet er {0}',
    badFormatMessage: '{0} er ikke et gyldig nummer'
});
