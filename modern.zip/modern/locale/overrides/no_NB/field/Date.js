Ext.define('Ext.locale.no_NB.field.Date', {
    override: 'Ext.field.Date',

    minDateMessage: 'Datoen i dette feltet må være etter {0}',
    maxDateMessage: 'Datoen i dette feltet må være før {0}'
});
