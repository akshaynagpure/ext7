Ext.define('Ext.locale.no_NB.field.Text', {
    override: 'Ext.field.Text',

    badFormatMessage: 'Verdi stemmer ikke overens med det nødvendige formatet',
    config: {
        requiredMessage: 'Dette feltet er påkrevd',
        validationMessage: 'Er i feil format'
    }
});
