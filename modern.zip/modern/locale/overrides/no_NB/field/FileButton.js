Ext.define("Ext.locale.no_NB.field.FileButton", {
    override: "Ext.field.FileButton",

    config: {
        text: 'Arkiv ...'
    }
});
