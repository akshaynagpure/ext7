Ext.define('Ext.locale.no_NB.field.Field', {
    override: 'Ext.field.Field',

    config: {
        requiredMessage: 'Dette feltet er påkrevd',
        validationMessage: 'Er i feil format'
    }
});
