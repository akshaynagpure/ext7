Ext.define('Ext.locale.no_NB.Dialog', {
    override: 'Ext.Dialog',

    config: {
        maximizeTool: {
            tooltip: "Maksimer til fullskjerm"
        },
        restoreTool: {
            tooltip: "Gjenopprett til originalstørrelse"
        }
    }
});
