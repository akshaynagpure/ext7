Ext.define('Ext.locale.no_NB.dataview.EmptyText', {
    override: 'Ext.dataview.EmptyText',

    config: {
        html: 'ingen data å vise'
    }
});
