Ext.define('Ext.locale.no_NB.dataview.List', {
    override: 'Ext.dataview.List',

    config: {
        loadingText: 'Laster...'
    }
});
