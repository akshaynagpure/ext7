Ext.define('Ext.locale.no_NB.dataview.plugin.ListPaging', {
    override: 'Ext.dataview.plugin.ListPaging',

    config: {
        loadMoreText: 'Legg inn mer ...',
        noMoreRecordsText: 'Ingen flere poster'
    }
});
