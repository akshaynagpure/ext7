Ext.define('Ext.locale.no_NB.dataview.Abstract', {
    override: 'Ext.dataview.Abstract',

    config: {
        loadingText: 'Laster...'
    }
});
