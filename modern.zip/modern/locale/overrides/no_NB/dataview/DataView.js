Ext.define("Ext.locale.no_NB.dataview.DataView", {
    override: "Ext.dataview.DataView",

    config: {
        emptyText: "ingen data som skal vises"
    }
});
