Ext.define('Admin.model.faq.Question', {
    extend: 'Admin.model.Base',

    fields: [
        {
            type: 'string',
            name: 'name'
        }
    ]
});
