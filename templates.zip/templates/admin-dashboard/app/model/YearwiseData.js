Ext.define('Admin.model.YearwiseData', {
    extend: 'Admin.model.Base',

    fields: [
        {
            name: 'year'
        },
        {
            name: 'data'
        }
    ]
});
