Ext.define('Admin.model.PersonalInfo', {
    extend: 'Admin.model.Base',

    fields: [
        {
            name: 'name'
        },
        {
            name: 'status'
        },
        {
            name: 'icon'
        }
    ]
});
