Ext.define('Admin.view.email.ComposeViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.emailcompose'

    // TODO - Add view data or remove if not needed
});