# core - Read Me

This package contains the core features common to Sencha frameworks.
