Ext.define('Ext.chart.theme.Red', {
    extend: 'Ext.chart.theme.Base',
    singleton: true,
    alias: [
        'chart.theme.red',
        'chart.theme.Red'
    ],
    config: {
        baseColor: '#e84b67'
    }
});
