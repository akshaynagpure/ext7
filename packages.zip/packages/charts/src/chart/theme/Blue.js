Ext.define('Ext.chart.theme.Blue', {
    extend: 'Ext.chart.theme.Base',
    singleton: true,
    alias: [
        'chart.theme.blue',
        'chart.theme.Blue'
    ],
    config: {
        baseColor: '#4d7fe6'
    }
});
