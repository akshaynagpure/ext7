/**
 * 
 */
Ext.define('Ext.chart.theme.BaseTheme', {
    defaultsDivCls: 'x-root'
});
