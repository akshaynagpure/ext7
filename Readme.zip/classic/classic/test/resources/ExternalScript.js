window.ElementLoaderTest = true;
